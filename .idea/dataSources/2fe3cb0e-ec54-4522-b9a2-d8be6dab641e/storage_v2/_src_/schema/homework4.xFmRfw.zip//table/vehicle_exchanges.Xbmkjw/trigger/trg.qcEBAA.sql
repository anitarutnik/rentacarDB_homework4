create definer = root@localhost trigger trg
    before insert
    on vehicle_exchanges
    for each row
BEGIN
    INSERT INTO trg_msg VALUES ('Message is added to each row');
END;

